from django.contrib import admin
from cbib.models import ResearchOutput, Author, Node

class AuthorAdmin(admin.ModelAdmin):
    list_display = ('title', 'first_name', 'last_name', 'role', 'display_node', 'email_address')
    list_filter = ('title', 'first_name', 'last_name', 'role', 'node')
admin.site.register(Author, AuthorAdmin)

@admin.register(ResearchOutput)
class ResearchOutputAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'display_coauthor', 'publication_type', 'year', 'upload_date', 'proof_of_verification', 'verification_link')
    list_filter = ('author', 'publication_type', 'year', 'upload_date', 'proof_of_verification')

@admin.register(Node)
class NodeAdmin(admin.ModelAdmin):
    list_display = ('name', 'location', 'description', 'node_code')
    list_filter = ('name', 'location')