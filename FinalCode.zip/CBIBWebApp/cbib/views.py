from django.http import HttpResponse
from django.shortcuts import render
from cbib.models import ResearchOutput, Author, Node



def index(request):

    num_research_outputs = ResearchOutput.objects.all().count()
    num_books = ResearchOutput.objects.filter(publication_type__exact='b').count()
    num_book_chapters = ResearchOutput.objects.filter(publication_type__exact='c').count()
    num_papers = ResearchOutput.objects.filter(publication_type__exact='p').count()
    num_journals = ResearchOutput.objects.filter(publication_type__exact='j').count()
    num_verified = ResearchOutput.objects.filter(proof_of_verification__exact='v').count()
    num_not_verified = ResearchOutput.objects.filter(proof_of_verification__exact='n').count()
    num_authors = Author.objects.count()
    num_nodes = Node.objects.all().count()

    num_visits = request.session.get('num_visits', 0)
    request.session['num_visits'] = num_visits + 1

    context = {
        'num_research_outputs': num_research_outputs,
        'num_books': num_books,
        'num_book_chapters': num_book_chapters,
        'num_papers': num_papers,
        'num_journals': num_journals,
        'num_verified': num_verified,
        'num_not_verified': num_not_verified,
        'num_authors': num_authors,
        'num_nodes': num_nodes,
        'num_visits': num_visits,
    }

    return render(request, 'index.html', context=context)

from django.views import generic

class ResearchOutputListView(generic.ListView):
    model = ResearchOutput
    paginate_by = 10

class ResearchOutputDetailView(generic.DetailView):
    model = ResearchOutput

class AuthorListView(generic.ListView):
    model = Author
    paginate_by = 10

class AuthorDetailView(generic.DetailView):
    model = Author

class NodeListView(generic.ListView):
    model = Node
    paginate_by = 10

class NodeDetailView(generic.DetailView):
    model = Node




from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Q

class DetailedResearchOutputListView(LoginRequiredMixin, generic.ListView):

    model = ResearchOutput
    template_name = 'cbib/detailedresearchoutput_list.html'
    paginate_by = 10

    def get_queryset(self):

        username = self.request.user.username

        if ('_' not in username):

            return ResearchOutput.objects.filter((Q(coauthor__first_name=self.request.user.first_name) & Q(coauthor__last_name=self.request.user.last_name)) | (Q(author__first_name=self.request.user.first_name) & Q(author__last_name=self.request.user.last_name)))

        else:

            nodeCode = username[-4:]

            return ResearchOutput.objects.filter(Q(author__node__node_code=nodeCode) | Q(coauthor__node__node_code=nodeCode))

class DetailedResearchOutputDetailView(generic.DetailView):

    model = ResearchOutput
    template_name = 'cbib/detailedresearchoutput_detail.html'




from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

class AuthorCreate(CreateView):
    model = ResearchOutput
    fields = '__all__'

class AuthorUpdate(UpdateView):
    model = ResearchOutput
    fields = '__all__'

class AuthorDelete(DeleteView):
    model = ResearchOutput
    success_url = reverse_lazy('detailed_research_outputs')




from django.shortcuts import render
import pdfkit

def downloadDetailedReportPDF(request, pk):

    if request.method == 'POST':

        options = {
            'page-size': 'Letter',
            'encoding': "UTF-8",
        }

        pdf = pdfkit.from_url('http://127.0.0.1:8000/cbib/detailed_research_output/' + str(pk), False, options)

        response = HttpResponse(pdf, content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="DetailedReport.pdf"'
        return response

    return render(request, 'cbib/download.html')


def downloadBasicReportPDF(request, pk):

    if request.method == 'POST':

        options = {
            'page-size': 'Letter',
            'encoding': "UTF-8",
        }

        pdf = pdfkit.from_url('http://127.0.0.1:8000/cbib/research_output/' + str(pk), False, options)

        response = HttpResponse(pdf, content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="BasicReport.pdf"'
        return response

    return render(request, 'cbib/download.html')


def downloadReportListPDF(request):

    if request.method == 'POST':

        options = {
            'page-size': 'Letter',
            'encoding': "UTF-8",
        }

        pdf = pdfkit.from_url('http://127.0.0.1:8000/cbib/research_outputs/', False, options)

        response = HttpResponse(pdf, content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="BasicReportList.pdf"'
        return response

    return render(request, 'cbib/download.html')


class OpenDetailedResearchOutputListView(generic.ListView):

    template_name = 'cbib/detailedresearchoutput_list.html'
    paginate_by = 10

    def get_queryset(self):

        username = self.request.user.username

        if ('_' not in username):

            return ResearchOutput.objects.filter((Q(coauthor__first_name=self.request.user.first_name) & Q(coauthor__last_name=self.request.user.last_name)) | (Q(author__first_name=self.request.user.first_name) & Q(author__last_name=self.request.user.last_name)))

        else:

            nodeCode = username[-4:]

            return ResearchOutput.objects.filter(Q(author__node__node_code=nodeCode) | Q(coauthor__node__node_code=nodeCode))


def downloadDetailedReportListPDF(request):

    if request.method == 'POST':

        options = {
            'page-size': 'Letter',
            'encoding': "UTF-8",
        }

        pdf = pdfkit.from_url('http://127.0.0.1:8000/cbib/open_detailed_research_outputs/', False, options)
        #pdf = pdfkit.from_url('http://127.0.0.1:8000/cbib/open_detailed_research_outputs/', False, options)

        response = HttpResponse(pdf, content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="DetailedReportList.pdf"'
        return response

    return render(request, 'cbib/download.html')


# My added code-----------------------------------------------------------
#from django.views.generic import TemplateView

#class AboutView(TemplateView):
#    template_name = "about.html"