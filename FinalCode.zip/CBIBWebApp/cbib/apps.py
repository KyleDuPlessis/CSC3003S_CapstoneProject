from django.apps import AppConfig


class CbibConfig(AppConfig):
    name = 'cbib'
