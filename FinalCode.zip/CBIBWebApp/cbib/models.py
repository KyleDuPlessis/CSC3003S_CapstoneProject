from django.db import models

# Create your models here.

from django.urls import reverse # Used to generate URLs by reversing the URL patterns
import datetime

"""
ResearchOutput Model
"""

class ResearchOutput(models.Model):

    title = models.CharField(max_length=300, help_text='Enter research output title')
    author = models.ForeignKey('Author', on_delete=models.SET_NULL, null=True, help_text='Select author', related_name='+')
    coauthor = models.ManyToManyField('Author', blank = True, help_text='Select co-author(s)')

    P_CHOICES = (
        ('b', 'Book'),
        ('c', 'Book Chapter'),
        ('p', 'Paper'),
        ('j', 'Journal'),
    )
    publication_type = models.CharField(max_length=1, choices=P_CHOICES, default='p', help_text='Select publication type')

    Y_CHOICES = [(r, r) for r in range(2000, datetime.date.today().year+1)]
    year = models.IntegerField(choices=Y_CHOICES, default=datetime.datetime.now().year, help_text='Select year')

    upload_date = models.DateField(help_text='Enter or select upload date')

    V_CHOICES = (
        ('v', 'Verified'),
        ('n', 'Not verified'),
    )

    proof_of_verification = models.CharField(max_length=1, choices=V_CHOICES, default='n', help_text='Select proof of verification')
    verification_link = models.URLField(help_text='Enter verification link', null=True, blank = True)

    abstract = models.TextField(help_text='Enter brief abstract')
    content = models.TextField(help_text='Enter research output content')

    def __str__(self):
        """String for representing the Model object."""
        return self.title

    def get_absolute_url(self):
        """Returns the url to access a detail record for this research output."""
        return reverse('researchoutput-detail', args=[str(self.id)])

    def get_absolute_url_detailed(self):
        """Returns the url to access a detail record for this research output."""
        return reverse('detailedresearchoutput-detail', args=[str(self.id)])

    def get_absolute_url_update(self):
        """Returns the url to access a detail record for this research output."""
        return reverse('updatedetailedresearchoutput-detail', args=[str(self.id)])

    def get_absolute_url_delete(self):
        """Returns the url to access a detail record for this research output."""
        return reverse('deletedetailedresearchoutput-detail', args=[str(self.id)])

    def get_absolute_url_pdf(self):
        """Returns the url to access a detail record for this research output."""
        return reverse('pdf-detail', args=[str(self.id)])

    def get_absolute_url_basicpdf(self):
        """Returns the url to access a detail record for this research output."""
        return reverse('basicpdf-detail', args=[str(self.id)])





    def display_coauthor(self):
        """Create a string for the Coauthor. This is required to display genre in Admin."""
        return ' & '.join(coauthor.last_name + ", " + coauthor.first_name for coauthor in self.coauthor.all()[:1000])

    display_coauthor.short_description = 'Coauthor'




"""
Author Model
"""

class Author(models.Model):

    N_CHOICES = (
        ('m', 'Mr'),
        ('s', 'Ms'),
        ('r', 'Mrs'),
        ('d', 'Dr.'),
        ('p', 'Prof.'),
        ('a', 'Assoc. Prof.'),
    )

    title = models.CharField(max_length=1, choices=N_CHOICES, default='m', help_text='Select title')
    first_name = models.CharField(max_length=200, help_text='Enter first name')
    last_name = models.CharField(max_length=200, help_text='Enter last name')

    R_CHOICES = (
        ('c', 'CAIR Member'),
        ('n', 'Node Administrator'),
        ('a', 'Researcher'),
        ('b', 'Associate'),
        ('d', 'Postdoctoral Fellow'),
        ('t', 'Student'),
        ('l', 'Alumni'),
        ('g', 'Office Management'),

    )

    role = models.CharField(max_length=1, choices=R_CHOICES, default='c',
                                             help_text='Select role')


    node = models.ManyToManyField('Node', help_text='Enter node')
    email_address = models.EmailField(help_text='Enter email address')

    class Meta:
        ordering = ['last_name']

    def get_absolute_url(self):
        """Returns the url to access a particular author instance."""
        return reverse('author-detail', args=[str(self.id)])

    def __str__(self):
        """String for representing the Model object."""
        return f'{self.last_name}, {self.first_name}'

    def display_node(self):
        """Create a string for the Node. This is required to display node in Admin."""
        return ', '.join(node.name for node in self.node.all()[:1000])

    display_node.short_description = 'Node'



"""
Node Model
"""

class Node(models.Model):

    name = models.CharField(max_length=200, help_text='Enter name')
    location = models.CharField(max_length=200, help_text='Enter location')
    description = models.TextField(help_text='Enter description')
    node_code = models.CharField(max_length=4, help_text='Enter node code', null = True)

    def __str__(self):
        """String for representing the Model object."""
        return f'{self.name}, {self.location}'

    def get_absolute_url(self):
        """Returns the url to access a particular author instance."""
        return reverse('node-detail', args=[str(self.id)])
