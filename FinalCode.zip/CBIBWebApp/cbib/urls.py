from django.urls import path
from django.views.generic import TemplateView
#from cbib.views import AboutView
from cbib import views

urlpatterns = [

    path('', views.index, name='index'),
# path('about/', AboutView.as_view()),
    path('research_outputs/', views.ResearchOutputListView.as_view(), name='research_outputs'),
    path('research_output/<int:pk>', views.ResearchOutputDetailView.as_view(), name='researchoutput-detail'),
    path('authors/', views.AuthorListView.as_view(), name='authors'),
    path('author/<int:pk>', views.AuthorDetailView.as_view(), name='author-detail'),
    path('nodes/', views.NodeListView.as_view(), name='nodes'),
    path('node/<int:pk>', views.NodeDetailView.as_view(), name='node-detail'),
    path('detailed_research_outputs/', views.DetailedResearchOutputListView.as_view(), name='detailed_research_outputs'),
    path('detailed_research_output/<int:pk>', views.DetailedResearchOutputDetailView.as_view(), name='detailedresearchoutput-detail'),
# path('about/', TemplateView.as_view(template_name="about.html")),

    ]


urlpatterns += [
    path('detailed_research_outputs/create/', views.AuthorCreate.as_view(), name='detailedresearchoutput_create'),
    path('detailed_research_output/<int:pk>/update/', views.AuthorUpdate.as_view(), name='updatedetailedresearchoutput-detail'),
    path('detailed_research_output/<int:pk>/delete/', views.AuthorDelete.as_view(), name='deletedetailedresearchoutput-detail'),

    path('detailed_research_output/<int:pk>/download/', views.downloadDetailedReportPDF, name='pdf-detail'),
    path('research_output/<int:pk>/download/', views.downloadBasicReportPDF, name='basicpdf-detail'),
    path('research_outputs/download/', views.downloadReportListPDF, name='pdflist_download'),

    path('open_detailed_research_outputs/', views.OpenDetailedResearchOutputListView.as_view(),
         name='open_detailed_research_outputs'),
    path('open_detailed_research_outputs/download/', views.downloadDetailedReportListPDF, name='detailedpdflist_download'),



]

""" from django.views.generic import TemplateView
 urlpatterns = patterns('',
        url(r'link_name_to_access^$', TemplateView.as_view(template_name="today.html")),

        path('about/', TemplateView.as_view(template_name='about.html')) 
  ) """


